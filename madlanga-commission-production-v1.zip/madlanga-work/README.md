# Madlanga Commission — Evidence Room

Production foundation for an evidence-first digital commission. This is not a simulation of the real Commission and does not manufacture findings. It models the public record and provides a structured interface for sourced research.

## Principles
- Primary sources outrank secondary reporting.
- Every material claim has provenance.
- Fact, mandate, record, allegation and analysis remain distinct.
- Hermes agents are constrained by evidence contracts.
- Contradictions are surfaced, not resolved by model confidence.
- Current state is date-stamped.

## Run
Serve the repository root with any static HTTP server, for example:

`python3 -m http.server 4173`

Open `http://localhost:4173/public/`.

## Next production integrations
1. Transcript/document ingestion pipeline.
2. Immutable source snapshots + hashes.
3. Full hearing index (all sitting days).
4. Claim extraction with human/agent verification gates.
5. Search index and evidence graph.
6. Hermes governance contracts and role souls (now defined under `hermes/`).
7. Hermes runtime with tool-level source restrictions.
8. Authentication/admin ingestion console.
9. Automated source freshness checks.
10. Test suite for citation/provenance invariants.
11. Deployment with server-side APIs; never expose privileged keys in the browser.

## Runtime status — 25 September 2026

The production foundation now includes a real, dependency-free Python evidence API and SQLite evidence store. It indexes all 178 recorded sitting days without inventing details for days whose source material has not been ingested. Six recent sitting records currently have detailed source links.

Implemented:
- SQLite source/claim/hearing/snapshot/audit schema.
- Deterministic `/api/status`, `/api/sources`, `/api/claims`, `/api/hearings`, `/api/search` and `/api/gate` endpoints.
- Controlled source-ingestion CLI that fetches a registered URL, SHA-256 hashes the bytes and writes an immutable snapshot.
- Evidence integrity tests and data validation.
- Browser UI connected to the API when available, with explicit static fallback.
- 178-day chronology view that labels un-ingested days as `index_only` instead of manufacturing dates or testimony.

The runtime has no third-party Python dependency. A hosted production deployment should move the same contracts to authenticated server-side services, object storage and Postgres/search infrastructure.
