# Source Hierarchy

Hermes evaluates sources by what they can directly establish, not by popularity.

## Tier 1 — Primary authoritative records
- Presidential proclamations and Government Gazettes.
- Official Commission publications, rulings, transcripts and documentary records.
- Official court judgments/orders where relevant.
- Other official records directly issued by a competent public institution.

## Tier 2 — Direct public record / controlled archive
- Reputable public archives reproducing or indexing Commission material.
- Faithful transcript/document repositories whose provenance can be inspected.

These sources must be labelled as archive/secondary infrastructure and should not silently be presented as official government records.

## Tier 3 — Reputable secondary reporting
- Established news organisations and specialist legal/public-affairs reporting.
- Useful for context, discovery and corroboration; not a replacement for a primary source when the primary record is available.

## Tier 4 — Tertiary/discovery material
- Search snippets, aggregators, social posts, unsourced summaries and user-generated material.
- May identify leads but cannot independently establish a material Commission fact.

## Conflict rule
If two sources disagree, retain both propositions, cite both, describe the nature of the disagreement and escalate for verification. Do not select a winner solely from source tier when the higher-tier source does not directly answer the disputed proposition.
