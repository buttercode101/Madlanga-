# Hermes Finding Gate

Hermes must not turn analysis into an official finding.

A proposed finding-like statement is eligible for synthesis only when all applicable checks pass:

- **Issue identified:** What precise proposition is being tested?
- **Evidence complete:** Relevant primary and contrary material has been retrieved or its absence is documented.
- **Source quality assessed:** Each source has a tier and provenance.
- **Attribution preserved:** Testimony/allegation is not upgraded without independent support.
- **Contrary evidence reviewed:** Credible conflicting material is surfaced.
- **Temporal integrity checked:** Dates and procedural state are consistent or conflicts are explicit.
- **Decision authority identified:** Any actual finding is attributed to the competent human/official authority.

If a required check fails, the gate is `conditional` or `blocked` and the missing work is named.
